<?php
/**
 * Include all available shortcodes
 *
 * @package GW2Embeds/Shortcodes
 */

/** Includes */
require_once GW2Embeds::$path . 'includes/shortcodes/function-aura.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-boon.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-coins.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-condi.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-control.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-icon.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-items.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-prof.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-skills.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-spec.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-traitline.php';
require_once GW2Embeds::$path . 'includes/shortcodes/function-traits.php';
// require_once GW2Embeds::$path . 'includes/shortcodes/function-traits.php';.
